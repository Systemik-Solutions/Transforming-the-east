<?php
/**
 * Plugin Name: SydneyUniv Custom Post Types
 * Description: This plugin adds the custom post type specific for this website template.
 * Version: 1.0.0
 * License: GPL2
 */

class sydneyunivACM {

    /**
     * Constructor. Called when plugin is initialised
     */
    function __construct() {
        add_action( 'init', array( $this, 'register_custom_post_type' ) );
    }

    function register_custom_post_type() {

        /**
         * Registers a Custom Post Type called Event
         */
        register_post_type('event', array(
            'labels' => array(
                'name'               => _x( 'Events', 'post type general name', 'sage' ),
                'singular_name'      => _x( 'Event', 'post type singular name', 'sage' ),
                'menu_name'          => _x( 'Events', 'admin menu', 'sage' ),
                'name_admin_bar'     => _x( 'Events', 'add new on admin bar', 'sage' ),
                'add_new'            => _x( 'Add New', 'Events', 'sage' ),
                'add_new_item'       => __( 'Add New Event', 'sage' ),
                'new_item'           => __( 'New Event', 'sage' ),
                'edit_item'          => __( 'Edit Event', 'sage' ),
                'view_item'          => __( 'View Event', 'sage' ),
                'all_items'          => __( 'All Events', 'sage' ),
                'search_items'       => __( 'Search Events', 'sage' ),
                'parent_item_colon'  => __( 'Parent Event:', 'sage' ),
                'not_found'          => __( 'No Events item found.', 'sage' ),
                'not_found_in_trash' => __( 'No Events item found in Trash.', 'sage' ),
            ),


            // Frontend
            'has_archive'        => false,
            'public'             => true,
            'hierarchical' => true,

            // Admin
            'capability_type' => 'post',
            'menu_icon'     => 'dashicons-store',
            'menu_position' => 5,
            'query_var'     => true,
            'show_in_menu'  => true,
            'show_ui'       => true,
            'supports' => array( 'title', 'editor', 'thumbnail'),
        ));
        register_taxonomy(
            'event-category',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces).
            'event',        //post type name
            array(
                'hierarchical' => true, // true = category like, false = tag like
                'label' => __( 'Categories' ),
                'show_admin_column' => true, // display in admin column
                'public' => true, // false = make private
                'show_in_menu'  => true,
                'show_ui'       => true,
                //'rewrite'       => array('slug' => 'our-brands','with_front' => false),
                'labels' => array(
                    'add_new_item'       => __( 'Add New Category', 'sage' ),
                    'parent_item_colon'  => __( 'Parent Category:', 'sage' ),
                )
            )
        );

    }
}

$sydneyunivACM = new sydneyunivACM;
